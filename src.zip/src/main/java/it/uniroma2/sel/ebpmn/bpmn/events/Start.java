package it.uniroma2.sel.ebpmn.bpmn.events;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import it.uniroma2.sel.ebpmn.bpmn.FlowNode;
import it.uniroma2.sel.ebpmn.bpmn.Participant;
import it.uniroma2.sel.ebpmn.events.*;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;
import it.uniroma2.sel.ebpmn.logger.CommunicationKind;
import it.uniroma2.sel.ebpmn.logger.LogData;
import it.uniroma2.sel.ebpmn.generators.RandomVariableGenerator;

public class Start extends FlowNode{
	//The Start node acts as a Token generator.

	private int nTokens;			//number of token to be generated
	/*
	 * A random variable generator is used to generate a sequence of
	 * interarrival times distributed according to a given probability distribution
	 */
	private RandomVariableGenerator generator;
	private int tokenID=1;
	private boolean logEnabled = false;

	public Start(String name, Participant p, RandomVariableGenerator gen, int nTokens) {
		super(name, p);
		//this.interArrivalTime = interArrivalTime;
		this.generator = gen;
		this.nTokens = nTokens;
	}
	
	public Start(String name, Participant p, RandomVariableGenerator gen, int nTokens, boolean enableLog) {
		super(name, p);
		this.generator = gen;
		this.nTokens = nTokens;
		this.logEnabled = enableLog;
		
	}
	
	public void setEnableLog(boolean enable) {
		this.logEnabled=enable;
	}

	public int getnTokens() {
		return nTokens;
	}

	public double getNextInterarrivalTime() {
		return generator.get();
	}

	@Override
	public void addOutGoingEdge(FlowNode n) {
		this.nodes.add(n);

	}

	@Override
	//A Start node has exactly 1 outgoing edge
	public FlowNode getNextNode() {
		return this.nodes.get(0);
	}

	@Override
	public void handleEvent(IncomingToken incomingToken) throws UnexpectedEvent{
		throw new UnexpectedEvent("Node " + this.getName() +
				"has received an unexpected INCOMING TOKEN event type");
	}

	@Override
	public void handleEvent(TokenServiceCompleted servedToken) throws UnexpectedEvent {
		throw new UnexpectedEvent("Node " + this.getName() +
				"has received an unexpected SERVICE COMPLETE event type");
	}

	@Override
	public void handleEvent(IncomingMessage message) throws UnexpectedEvent {
		throw new UnexpectedEvent("Node " + this.getName() +
				"has received an unexpected INCOMING MESSAGE event type");
	}

	@Override
	public void handleEvent(StartProcess startEvent) throws UnexpectedEvent {
		IncomingToken token = new IncomingToken(Integer.toString(tokenID),startEvent.getTime(),
				this.getNextNode(),startEvent.getTime());

		//LOG
		System.out.println(startEvent.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
				+ ": Scheduled INCOMING TOKEN, Token ID " + token.getTokenId() + " to " + token.getTargetEntity().getName());

		this.getNextNode().dispatchEventOn(token);
		//engine.getEventsList().addEvent(token);
		tokenID++;

		/* the log is written if the feature is enabled otherwise the START node behavior is not tracked.
		* Might be useful depending on the capabilities provided by the log analysis tool
		*/
		if(logEnabled) log(token.getTokenId(), token.getTime());
	}



	/*
	@Override
	public void handleEvent(Event e) throws UnexpectedEvent {
		//Start only admits START_PROCESS events
		if(e instanceof StartProcess) {

			IncomingToken token = new IncomingToken(Integer.toString(tokenID),e.getTime(),
	            						this.getNextNode(),e.getTime());
			
			//LOG
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
					+ ": Scheduled INCOMING TOKEN, Token ID " + token.getTokenId() + " to " + token.getTargetEntity().getName());
			engine.getEventsList().addEvent(token);			
			tokenID++;
			
			/* the log is written if the feature is enabled otherwise the
			   START node behavior is not tracked.
			   Might be useful depending on the capabilities provided by the log analysis tool
			  *
			if(logEnabled)
				log(token.getTokenId(), token.getTime());
		}
		else throw new UnexpectedEvent("Node " + this.getName() +
				"has received an unexpected " + e.getClass().getSimpleName().toUpperCase() + " event type");

	}
	*/
	
	private void log(String tokenId, double tokenLogicalTime) {
		
		LogData ld = new LogData();
		LocalDateTime initialTime = engine.getInitialTime();
		DateTimeFormatter dateTimeFormat = engine.getDateTimeFormat(); 
		
		//token ID corresponds to the case ID
		ld.setCaseId(tokenId);  
		
		/*
		 * An intermediate throw event does not add any delay in forwarding
		 * the token (i.e., it does not require any time to be computed)
		 * Only the completion time is recorded
		 * */
		
		ld.setStartTimestamp("");
		
		long seconds;
		long nanos;
		seconds = (long) tokenLogicalTime;
        nanos = (long) ((tokenLogicalTime - seconds) * 1_000_000_000);
        
        //The completion time is the initial time + the current token logical time
        ld.setCompleteTimestamp(initialTime.plusSeconds(seconds).plusNanos(nanos).format(dateTimeFormat));
        ld.setActivity(this.name);
        /*
         * As an intermediate event does not execute any
         * action, it does not requires any resource as well
         * 
         */
        ld.setResources("");
        ld.setRoles("");
        ld.setLocalEntity(this.getParticipant().getName());
        ld.setRemoteEntity("");
        ld.setCommType(CommunicationKind.ND);
        ld.setData("");
	
        this.writeLog(ld);
	}



}
