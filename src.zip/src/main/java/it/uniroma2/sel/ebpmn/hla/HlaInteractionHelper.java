package it.uniroma2.sel.ebpmn.hla;

import hla.rti1516e.*;
import hla.rti1516e.exceptions.*;


public class HlaInteractionHelper {

    private final RTIambassador rti;
    private InteractionClassHandle incomingTokenHandle;
    private InteractionClassHandle incomingMessageHandle;
    private InteractionClassHandle joinNotificationClassHandle;

    public HlaInteractionHelper(RTIambassador rti) {
        this.rti = rti;
    }

    public void sendJoinNotificationInteraction() {
        ParameterHandleValueMap parameters = null;
        try {
            parameters = rti.getParameterHandleValueMapFactory().create(0);
            rti.sendInteraction(joinNotificationClassHandle, parameters, null);
        } catch (FederateNotExecutionMember | NotConnected | InteractionClassNotPublished |
                 InteractionParameterNotDefined | InteractionClassNotDefined | SaveInProgress | RestoreInProgress |
                 RTIinternalError e) {
            throw new RuntimeException(e);
        }
    }

    public void publishAndSubscribeJoinNotificationInteraction() throws RTIexception{
        joinNotificationClassHandle = rti.getInteractionClassHandle("HLAinteractionRoot.FederationJoined");
        rti.publishInteractionClass(joinNotificationClassHandle);
        rti.subscribeInteractionClass(joinNotificationClassHandle);
    }

    public void publishAndSubscribe() throws RTIexception {
        incomingTokenHandle = rti.getInteractionClassHandle("HLAinteractionRoot.IncomingToken");
        rti.publishInteractionClass(incomingTokenHandle);
        rti.subscribeInteractionClass(incomingTokenHandle);

        incomingMessageHandle = rti.getInteractionClassHandle("HLAinteractionRoot.IncomingMessage");
        rti.publishInteractionClass(incomingMessageHandle);
        rti.subscribeInteractionClass(incomingMessageHandle);
    }

    public InteractionClassHandle getJoinNotificationHandle() { return joinNotificationClassHandle; }
    public InteractionClassHandle getIncomingTokenHandle() { return incomingTokenHandle; }
    public InteractionClassHandle getIncomingMessageHandle() { return incomingMessageHandle; }
}
