package it.uniroma2.sel.ebpmn.bpmn;

import java.util.ArrayList;

public class Participant {

	private String name; //participant name
	private boolean isInitiating;
	
	/*
	 * The process collection includes all the flownode elements
	 * composing the process executed by the participant
	 * */
	ArrayList<FlowNode> process;

	public Participant(String name, boolean isInitiating) {
		this.name = name;
		this.isInitiating = isInitiating;
		process = new ArrayList<>();
	}

	public String getName() {
		return name;
	}
	
	public boolean isInitiating() {
		return this.isInitiating;
	} 

	public void setName(String name) {
		this.name = name;
	}

	public void addFlowNode(FlowNode n) {
		process.add(n);
	}

	public FlowNode getFlowNode(int i) {
		return process.get(i);
	}

	public FlowNode getStartNode() {
		return process.get(0);
	}

	public FlowNode getEndNode() {
		return process.get(process.size()-1);
	}

}
