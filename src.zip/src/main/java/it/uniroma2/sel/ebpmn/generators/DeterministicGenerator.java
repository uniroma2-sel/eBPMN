package it.uniroma2.sel.ebpmn.generators;

public class DeterministicGenerator implements RandomVariableGenerator{

	private double deterministicValue;

	public DeterministicGenerator(double value) {
        this.deterministicValue = value;
    }
    @Override
    public double get() {
        // Generation of a random number according to an Uniform probability distribution
        return deterministicValue;
    }
}
