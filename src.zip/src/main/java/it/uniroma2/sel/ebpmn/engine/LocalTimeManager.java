package it.uniroma2.sel.ebpmn.engine;

public class LocalTimeManager implements TimeManager{
    private volatile double currentTime;

    public LocalTimeManager() {
        this.currentTime = 0.0;
    }

    public LocalTimeManager(double currentTime) {
        this.currentTime = currentTime;
    }

    @Override
    public double advanceTo(double newTime) {
        this.currentTime = newTime;
        return currentTime;
    }

    @Override
    public double getCurrentTime() { return currentTime; }

}
