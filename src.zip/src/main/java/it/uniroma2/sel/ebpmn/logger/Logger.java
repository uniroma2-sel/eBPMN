package it.uniroma2.sel.ebpmn.logger;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public abstract class Logger {
	protected BufferedWriter writer;
	
	public Logger (String fileName) {
		try {
			writer = Files.newBufferedWriter(Paths.get(fileName));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
    public abstract void write(LogData data);
    
    public void closeLog() {
    	try {
			writer.flush();
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
    
}
