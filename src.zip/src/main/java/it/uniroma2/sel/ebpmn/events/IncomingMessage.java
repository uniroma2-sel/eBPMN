package it.uniroma2.sel.ebpmn.events;

import it.uniroma2.sel.ebpmn.bpmn.FlowNode;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;

public class IncomingMessage extends Event{
	private String messagePayload;
	private FlowNode sourceEntity;
	public IncomingMessage(double time, FlowNode sourceEntity, FlowNode destinationEntity, String data) {
		super(time, destinationEntity);
		this.messagePayload = data;
		this.sourceEntity = sourceEntity;
	}

	@Override
	public void processOn(FlowNode node) throws UnexpectedEvent {
		node.handleEvent(this);  // double dispatch
	}

	public String getMessagePayload() {
		return messagePayload;
	}
	
	public FlowNode getSourceEntity() {
		return sourceEntity;
	}

}
