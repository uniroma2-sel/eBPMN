package it.uniroma2.sel.ebpmn.bpmn;

import java.util.ArrayList;

import it.uniroma2.sel.ebpmn.engine.ExecutionEngine;
import it.uniroma2.sel.ebpmn.events.*;
import it.uniroma2.sel.ebpmn.exceptions.BPMNException;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;
import it.uniroma2.sel.ebpmn.logger.LogData;
import it.uniroma2.sel.ebpmn.bpmn.Node;


/*
* A FlowNode is the abstract BPMN local entity which implements the Node interface
* */
public abstract class FlowNode implements Node {
	protected String name;		//name of the bpmn flow node
    protected ArrayList<FlowNode> nodes; 	// list of flow nodes 
    									 	//connected to the outgoing edges
    protected Participant p;		//participant that contains the bpmn flow node
	protected ExecutionEngine engine = ExecutionEngine.getInstance(); //the execution engine is a semi-singleton

    public FlowNode(String name, Participant p) {
    	nodes = new ArrayList<>();
		this.name = name;
		p.addFlowNode(this);
		this.p = p;
		//tokenQueue = new TreeSet<>();
	}

    public String getName() {
    	return name;
    }

    //participant to whom the node belongs
    public Participant getParticipant() {
    	return p;
    }

	//creates an outgoing edge with routing probability equal to 1
	public abstract void addOutGoingEdge(FlowNode n) throws BPMNException;

	//gets the next node connected to the unique outgoing edge
	public abstract FlowNode getNextNode() throws BPMNException;

	/*
	 * handlers for the incoming event
	 */
	public  void handleEvent(IncomingToken incomingToken) throws UnexpectedEvent{
		throw new UnexpectedEvent("Node " + this.getName() +
				"has received an unexpected INCOMING TOKEN event type");
	}
	public  void handleEvent(TokenServiceCompleted servedToken) throws UnexpectedEvent{
		throw new UnexpectedEvent("Node " + this.getName() +
				"has received an unexpected TOKEN SERVICE COMPLETE event type");
	}
	public  void handleEvent(IncomingMessage message) throws UnexpectedEvent{
		throw new UnexpectedEvent("Node " + this.getName() +
				"has received an unexpected INCOMING MESSAGE event type");
	}
	public  void handleEvent(StartProcess startEvent) throws UnexpectedEvent{
		throw new UnexpectedEvent("Node " + this.getName() +
				"has received an unexpected START PROCESS event type");
	}

	@Override
	public void dispatchEventOn(Event e) {
		/*
		* Events dispatched to a local entity are added to the local events queue managed
		* by the simulation engine.
		* Please note that events dispatched to remote entities generates interactions that will be
		* handled by the federate which provide the actual implementation of the target entity
		* (See the implementation of the dispatchEvent() method for the RemoteEntity Class)*/
		engine.scheduleLocalEvent(e);
	}


	protected void writeLog(LogData ld) {
		engine.getLogger(this.getParticipant().getName()).write(ld);
	}
}
