package it.uniroma2.sel.ebpmn.generators;
/*
 * Generator of random numbers according to a given probability distribution function
 * */

public interface RandomVariableGenerator {
    public double get();

}