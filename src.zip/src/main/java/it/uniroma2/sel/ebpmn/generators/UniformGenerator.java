package it.uniroma2.sel.ebpmn.generators;

import java.util.Random;

public class UniformGenerator implements RandomVariableGenerator{
	private final Random random = new Random();
    @Override
    public double get() {
        // Generation of a random number according to an Uniform probability distribution
        return random.nextDouble();
    }
}
