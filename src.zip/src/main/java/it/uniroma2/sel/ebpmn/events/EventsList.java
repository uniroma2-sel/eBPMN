package it.uniroma2.sel.ebpmn.events;

import java.util.ArrayList;
import java.util.Comparator;

public class EventsList {
	private ArrayList<Event> events;

	public EventsList() {
		events = new ArrayList<>();
	}

	public Event getNextEvent() {
		return events.get(0);
	}

	public Event getAndRemoveNextEvent(){
		Event e = events.get(0);
		events.remove(0);
		return e;
	}

	public void removeEvent(Event e){
		events.remove(e);
	}

	public void addEvent(Event e) {
		events.add(e);
		events.sort(Comparator.comparingDouble(Event::getTime));
	}

	public boolean isEmpty() {
		return events.isEmpty();
	}

	public ArrayList<Event> getList(){
		return this.events;
	}
}
