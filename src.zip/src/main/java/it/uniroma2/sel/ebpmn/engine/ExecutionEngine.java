package it.uniroma2.sel.ebpmn.engine;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

import it.uniroma2.sel.ebpmn.bpmn.Collaboration;
import it.uniroma2.sel.ebpmn.bpmn.Participant;
import it.uniroma2.sel.ebpmn.bpmn.events.End;
import it.uniroma2.sel.ebpmn.bpmn.events.Start;
import it.uniroma2.sel.ebpmn.configuration.SimulationConfig;
import it.uniroma2.sel.ebpmn.events.Event;
import it.uniroma2.sel.ebpmn.events.EventsList;
import it.uniroma2.sel.ebpmn.events.StartProcess;
import it.uniroma2.sel.ebpmn.exceptions.EventInThePastException;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;
import it.uniroma2.sel.ebpmn.hla.HlaAdapter;
import it.uniroma2.sel.ebpmn.hla.HlaFactory;
import it.uniroma2.sel.ebpmn.logger.Logger;


public class ExecutionEngine {

	private double simulationTime = 0.0;
	//private static TreeSet<Event> eventList;
	private EventsList eventsList; //list of events to be processed
	private Collaboration model;
	private static volatile ExecutionEngine instance; //semi-singleton
	private TimeManager timeManager;
	private HlaAdapter adapter = null;	// adapter that manages the service requests to the RTI -
										// different vendor-specific implementations might be provided
										// currently only a Pitch-specific implementation (HlaAdapterImpl) is available

	//private Logger logHandler;
	private HashMap<String, Logger> logs;
	private LocalDateTime initialTime;	//physical time to be logged
	private DateTimeFormatter dateTimeFormat;
	private SimulationConfig config;
	
	private ExecutionEngine(SimulationConfig config){
		eventsList = new EventsList();	
		logs = new HashMap<String, Logger>();
		// default physical time format
        dateTimeFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss.SSS");
        initialTime = LocalDateTime.now(); // default initial time
		this.config = config;

		if (config.getSimulationType() == SimulationConfig.SimulationType.DISTRIBUTED) {
			//Initialization of the HLA distributed infrastructure
            try {
                this.adapter = HlaFactory.create(config);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
			//the distributed time manager interacts with the RTI (via the adapter) to handle the time advance requests
            this.timeManager = new DistributedTimeManager(adapter);
			System.out.println("[ENGINE] Distributed Time Manger initialized.");
		} else {
			this.timeManager = new LocalTimeManager();
			System.out.println("[ENGINE] Local Time Manger initialized.");
		}
		ExecutionEngine.instance = this;
	}

	public static synchronized ExecutionEngine initialize(SimulationConfig config) {
		if (instance != null) {
			throw new IllegalStateException("[ENGINE] ExecutionEngine already initialized.");
		}
		instance = new ExecutionEngine(config);
		return instance;
	}

	public HlaAdapter getAdapter() {
		return adapter;
	}

	public static ExecutionEngine getInstance() {
		if (instance == null)
			throw new IllegalStateException("Engine not initialized yet");
		return instance;
	}

	public void setModel(Collaboration model){
		this.model = model;
	}

	public void setLogger(String participantName, Logger log) {
		logs.put(participantName, log);
	}
	
	public Logger getLogger(String participantName) {
		return logs.get(participantName);
	}
	
	public LocalDateTime getInitialTime() {
		return initialTime;
	}

	public double getSimulationTime() {
		return simulationTime;
	}

	public void setInitialTime(String initialTimeAsString) {
		this.initialTime = LocalDateTime.parse(initialTimeAsString, dateTimeFormat);
	}

	public DateTimeFormatter getDateTimeFormat() {
		return dateTimeFormat;
	}

	public void setFormatter(String formatString) {
		this.dateTimeFormat = DateTimeFormatter.ofPattern(formatString);
	}

	//DA RIMUOVERE
	/*public EventsList getEventsList(){
		return eventsList;
	}*/

	public void scheduleLocalEvent(Event e){
		eventsList.addEvent(e);
	}

	public void run() throws EventInThePastException, UnexpectedEvent {
		System.out.println("[ENGINE] " + config.getSimulationType() + " SIMULATION START ");
		init();

		//Simulation main loop
		while(!eventsList.isEmpty()) {
			Event e = eventsList.getNextEvent();
			double nextTime = e.getTime();
			if(nextTime<simulationTime) {
				// violation of the causality principle
				throw new EventInThePastException("Event " + e.getClass().getName() + "for " + e.getTargetEntity()
				+ "at time " + nextTime + " happened in the past. Current Simulation time: " + simulationTime);
			}else {
				//time advance
				//simulationTime=e.getTime();
				simulationTime = timeManager.advanceTo(nextTime);
				eventsList.removeEvent(e);
				//execution of the event handler
				//e.getTargetEntity().handleEvent(e);
				e.processOn(e.getTargetEntity());
			}
		}


		System.out.println("\n" +"[ENGINE] SIMULATION END");
		logs.forEach((key,log)->log.closeLog());
		
		System.out.println("\n\n" +"****************************************\n" + "RESULTS");
		for (Participant participant : model.getParticipants()) {
            System.out.println("Process " + participant.getName());
            End end= (End) participant.getEndNode();
            System.out.println("Processed tokens :" + end.getProcessedToken());
            System.out.println("Elapsed Time (mean value) :" + end.getAvgServiceTime());
		}

	}

	private void init() {
		/*
		 * create an initial set of INCOMING_TOKEN events according to
		 * the interarrival time and the number of token specified for each participant
		 * */
		Start s;

		System.out.println("\n*** Initialization Process...");

		for (Participant participant : model.getParticipants()) {
            System.out.println("*** Found Participant Name: " + participant.getName());
            s= (Start) participant.getStartNode();

            if(participant.isInitiating()) {
            	System.out.println("*** Found Start Node: " + s.getName() + " Tokens: "+ s.getnTokens() + " to: " + s.getNextNode().getName());

                double timestamp=0;
                for(int i=1; i<=s.getnTokens();i++) {
                	//eventsList.addEvent(new IncomingToken(Integer.toString(i),timestamp,
                	//					s.getNextNode(),timestamp));
                	eventsList.addEvent(new StartProcess(timestamp,s));
                	timestamp += s.getNextInterarrivalTime();
                }
            }
            
            
            
        }
		System.out.println("*** Initialization Completed \n");
	}

}
