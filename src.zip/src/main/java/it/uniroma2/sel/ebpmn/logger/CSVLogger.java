package it.uniroma2.sel.ebpmn.logger;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class CSVLogger extends Logger {

	public CSVLogger(String fileName) {
		super(fileName);
		try {
			writer = Files.newBufferedWriter(Paths.get(fileName));
			//adding the csv header
			writer.write("CaseId,"
					+ "StartTimestamp,"
					+ "CompletionTimestamp,"
					+ "Activity,"
					+ "Resource,"
					+ "Role,"
					+ "LocalEntity,"
					+ "RemoteEntity,"
					+ "CommunicationType,"
					+ "Data");
			writer.newLine();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
	}

	//@Override
	public void write(LogData data) {
		try {
			//adding comma separated values
			writer.write(String.valueOf(data.getCaseId()) + ","
					+ data.getStartTimestamp().toString() + ","
					+ data.getCompleteTimestamp().toString() + ","
					+ data.getActivity() + ","
					+ data.getResources() + ","
					+ data.getRoles() + ","
					+ data.getLocalEntity() + ","
					+ data.getRemoteEntity() + ","
					+ data.getCommType() + ","
					+ data.getData());
			writer.newLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
