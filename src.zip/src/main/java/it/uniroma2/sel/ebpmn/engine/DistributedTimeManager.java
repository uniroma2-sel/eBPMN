package it.uniroma2.sel.ebpmn.engine;

import it.uniroma2.sel.ebpmn.hla.HlaAdapter;

public class DistributedTimeManager implements TimeManager {

    private volatile double currentTime;
    private final HlaAdapter hla;

    public DistributedTimeManager(HlaAdapter hla) {
        this.hla = hla;
        this.currentTime = 0.0;
    }

    public DistributedTimeManager(HlaAdapter hla, double currentTime) {
        this.hla = hla;
        this.currentTime = currentTime;
    }

    @Override
    public double advanceTo(double nextTime) {
        try {
            hla.requestTimeAdvance(nextTime);
            hla.waitForTimeAdvanceGrant();
            currentTime = nextTime;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return currentTime;
    }

    public double getCurrentTime() { return currentTime; }
}