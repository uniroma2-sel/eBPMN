package it.uniroma2.sel.ebpmn.hla;

import hla.rti1516e.*;
import hla.rti1516e.exceptions.FederateInternalError;
import it.uniroma2.sel.ebpmn.engine.ExecutionEngine;

import java.util.HashSet;
import java.util.Set;


public class FederateAmbassadorImpl extends NullFederateAmbassador {
    private HlaAdapter adapter;
    private static final String READY_TO_RUN = "READY_TO_RUN";
    private boolean isTimeRegulating  = false; //check if the federate is time regulating
    private boolean isTimeConstrained = false; //check if the federate is time constrained
    private boolean isReadyToRunAnnounced = false; 	//check if ReadyToRun sync point has been announced
    private boolean isReadyToRunAchieved = false; 	//check if ReadyToRun sync point has been achieved
    private boolean isAdvancing = false;   //check if the RTI granted the time advance request
    private int joinedFederates = 0;       // number of federates that currently joined the federation execution

    private final Set<ObjectInstanceHandle> discoveredHandles = new HashSet<>();

    public void setHlaAdapter(HlaAdapter hlaAdapter){
        adapter=hlaAdapter;
    }

    public void notifyJoinedFederate(){
        joinedFederates++;
    }

    public int getJoinedFederates(){
        return joinedFederates;
    }

    public boolean isTimeRegulating() {
        return isTimeRegulating;
    }

    public boolean isTimeConstrained() {
        return isTimeConstrained;
    }

    void setAdvancingState(){
        isAdvancing = true;
    }

    public boolean isAdvancing() {
        return isAdvancing;
    }

    public boolean isReadyToRunAnnounced() {
        return isReadyToRunAnnounced;
    }

    public boolean isReadyToRunAchieved() {
        return isReadyToRunAchieved;
    }

    @Override
    public void timeAdvanceGrant(LogicalTime theTime) throws FederateInternalError {
        synchronized (this) {
            isAdvancing = false;
            this.notifyAll();
        }
    }

    @Override
    public void timeConstrainedEnabled(LogicalTime time) throws FederateInternalError {
        synchronized (this) {
            isTimeConstrained = true;
            this.notify();
        }
    }

    @Override
    public void timeRegulationEnabled(LogicalTime time) throws FederateInternalError {
        synchronized (this) {
            isTimeRegulating = true;
            this.notify();
        }
    }

    @Override
    public void synchronizationPointRegistrationFailed(String label,
                                                       SynchronizationPointFailureReason reason) throws FederateInternalError {
        System.out.println("[FederateAmbassador] Sync Point Registration Failed:  " + label + reason);
    }

    @Override
    public void announceSynchronizationPoint(String label, byte[] tag) {
        if (label.equals(READY_TO_RUN)) {
            synchronized (this) {
                isReadyToRunAnnounced = true;
                this.notifyAll();
            }
        }
    }

    @Override
    public void federationSynchronized(String label, FederateHandleSet failed) {
        if (label.equals(READY_TO_RUN)) {
            synchronized (this) {
                isReadyToRunAchieved = true;
                this.notifyAll();
            }
        }
    }


    @Override
    public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters, byte[] userSuppliedTag, OrderType sentOrdering, TransportationTypeHandle theTransport, LogicalTime theTime, OrderType receivedOrdering, MessageRetractionHandle retractionHandle, SupplementalReceiveInfo receiveInfo) throws FederateInternalError {
        System.out.println("[FederateAmbassador] received interaction cccc");
    }

    @Override
    public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters, byte[] userSuppliedTag, OrderType sentOrdering, TransportationTypeHandle theTransport, LogicalTime theTime, OrderType receivedOrdering, SupplementalReceiveInfo receiveInfo) throws FederateInternalError {
        System.out.println("[FederateAmbassador] received interaction bbb");
    }

    @Override
    public void receiveInteraction(InteractionClassHandle interactionClass, ParameterHandleValueMap theParameters, byte[] userSuppliedTag, OrderType sentOrdering, TransportationTypeHandle theTransport, SupplementalReceiveInfo receiveInfo) throws FederateInternalError {
        System.out.println("[FederateAmbassador] received interaction aaaa");

        /*
        * The Join Notification interaction is received when a new federate joins the federation
        * */
        if (interactionClass.equals(adapter.getJoinNotificationClassHandle())) {
            synchronized (this) {
                joinedFederates++;
                System.out.println("Federate joined (" + joinedFederates + ")");
                notifyAll();
            }
        }
    }
}