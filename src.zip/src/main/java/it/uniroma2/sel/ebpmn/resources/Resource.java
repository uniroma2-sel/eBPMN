package it.uniroma2.sel.ebpmn.resources;

import java.util.ArrayList;

import it.uniroma2.sel.ebpmn.bpmn.tasks.Task;

public class Resource {
	private String name;			//resource name
	private String role;			//role which the resource assumes in his/her/its organization
	private boolean isAvailable;	//
	private ArrayList<Task> tasks;	//list of tasks associated to the resource

	public Resource(String n, String r){
		this.name = n;
		this.role = r;
		isAvailable = true;
		tasks = new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public String getRole() {
		return role;
	}

	public boolean isAvailabe() {
		return this.isAvailable;
	}

	public void setBusy() {
		this.isAvailable = false;
	}

	public void free() {
		this.isAvailable = true;
	}

	public void addTask(Task t) {
		this.tasks.add(t);
	}

	public ArrayList<Task> getTasks(){
		return this.tasks;
	}
}
