package it.uniroma2.sel.ebpmn.events;

import it.uniroma2.sel.ebpmn.bpmn.FlowNode;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;

public abstract class Event implements Comparable<Event>{
	private double time; 		//event logical time
	private FlowNode targetEntity; 	//BPMN entity which implements the event handler
	private Double startTimestamp;	//if provided stores the time the token was generated

	public Event(double time, FlowNode entity) {
		this.time = time;
		this.targetEntity = entity;
	}

	public Event(double time, FlowNode entity, double startTime) {
		this.time = time;
		this.targetEntity = entity;
		this.startTimestamp = startTime;
	}

	public Double getStartTimestamp() {
		return this.startTimestamp;
	}

	public double getTime() {
		return time;
	}

	public void setTime(double time) {
		this.time = time;
	}

	public FlowNode getTargetEntity() {
		return targetEntity;
	}

	public void setTargetEntity(FlowNode node) {
		this.targetEntity = node;
	}

	public abstract void processOn(FlowNode node) throws UnexpectedEvent;

	@Override
	public int compareTo(Event o) {
		return Double.compare(this.getTime(), o.getTime());
	}

}

