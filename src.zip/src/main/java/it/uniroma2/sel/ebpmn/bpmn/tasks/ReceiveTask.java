package it.uniroma2.sel.ebpmn.bpmn.tasks;

import java.util.ArrayList;
import java.util.TreeSet;

import it.uniroma2.sel.ebpmn.bpmn.FlowNode;
import it.uniroma2.sel.ebpmn.bpmn.Participant;
import it.uniroma2.sel.ebpmn.events.Event;
import it.uniroma2.sel.ebpmn.events.IncomingMessage;
import it.uniroma2.sel.ebpmn.events.IncomingToken;
import it.uniroma2.sel.ebpmn.events.TokenServiceCompleted;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;
import it.uniroma2.sel.ebpmn.logger.CommunicationKind;
import it.uniroma2.sel.ebpmn.logger.LogData;
import it.uniroma2.sel.ebpmn.resources.Resource;
import it.uniroma2.sel.ebpmn.generators.RandomVariableGenerator;

public class ReceiveTask extends Task{
	
	private TreeSet<Event> messageQueue;
	
	public ReceiveTask(String name, Participant p, RandomVariableGenerator gen) {
		super(name, p, gen);
		messageQueue = new TreeSet<>();
	}
	
	public boolean isMessageQueueEmpty() {
		return this.messageQueue.isEmpty();
	}


	@Override
	public void handleEvent(IncomingMessage incomingMessage) throws UnexpectedEvent {
		System.out.println(incomingMessage.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
				+ ": Received INCOMING MESSAGE");
		ProcessMessage(incomingMessage);
	}

	/*
	@Override
	public void handleEvent(Event e) throws UnexpectedEvent{
		/*
		 * A task is associated to a pool of resources which are in charge of
		 * executing or overseeing the relevant activity. Resources might be responsible
		 * of more than one task.
 		 *
		 * *
		if(e instanceof IncomingToken) {
			//LOG
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
				+ ": Received INCOMING TOKEN, Token ID " + ((IncomingToken)e).getTokenId());
			processToken((IncomingToken)e);
		}

		else if(e instanceof TokenServiceCompleted) {
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
			+ ": Received SERVICE COMPLETE, Token ID " + ((TokenServiceCompleted)e).getTokenId());
        	completeTokenService((TokenServiceCompleted)e);
		}
		
		else if(e instanceof IncomingMessage) {			
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
					+ ": Received INCOMING MESSAGE");
			ProcessMessage((IncomingMessage)e);
		}

		else throw new UnexpectedEvent("Node " + this.getName() +
				"has received an unexpected " + e.getClass().getSimpleName().toUpperCase() + " event type");
	}
	*/
	
	
	@Override
	protected void processToken(IncomingToken e) {
		initialTime = engine.getInitialTime();
		dateTimeFormat = engine.getDateTimeFormat(); 
		IncomingMessage message;
		
		/* if at least on resource is available and an incoming message is available, 
		 * the token is processed. Otherwise it is enqueued.
		 */

		if (checkForAvailableResource() && !this.messageQueue.isEmpty()) {
			
			//a message is consumed
			message = (IncomingMessage)messageQueue.pollFirst(); //message consumed
			
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": Found available message ");
			
			//find the next to be used according to a round robin policy
			Resource r = this.getAvailableResource();

			//DEBUG
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": Found available resource " + r.getName() );
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": Starting processing of Token ID " + e.getTokenId());
	

			//mark the resource as busy
			r.setBusy();

			//a SERVICE_COMPLETE event is scheduled on this entity
			serviceTime = generator.get();
			TokenServiceCompleted serviceCompleteEvent = new TokenServiceCompleted(e.getTokenId(),
					e.getTime()+serviceTime, this, e.getStartTimestamp());
			serviceCompleteEvent.setResource(r);
			this.dispatchEventOn(serviceCompleteEvent);
			//l.addEvent(serviceCompleteEvent);
			
			//Writing the log entry
			log(e.getTokenId(), e.getTime(), serviceTime, message.getSourceEntity().getParticipant().getName(), message.getMessagePayload());
	        
			//LOG
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": Scheduled SERVICE COMPLETE event for Token ID " + serviceCompleteEvent.getTokenId() + " at time "
				+ serviceCompleteEvent.getTime()
				+ " for " + serviceCompleteEvent.getTargetEntity().getName());
		} else {
			//the token is enqueued
			this.tokenQueue.add(e);
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + " Token ID " + e.getTokenId() + " enqueued");
		}
	}

	
	@Override
	protected void completeTokenService(TokenServiceCompleted e) {
		//LOG
		System.out.println(e.getTime() + ")  " + this.getParticipant().getName() + " - " 
		+ this.getName() + ": Token " + e.getTokenId() + " Served ");
		System.out.println(e.getTime() + ")  " + this.getParticipant().getName() + " - "
		+ this.getName() + ": Resource " + e.getResource().getName() + " is now free");

		//the involved resource is marked as available
		Resource r = e.getResource();
		r.free();

		/*
		 * To route the token towards the next node, a new INCOMING_TOKEN event is created
		 * */
		FlowNode targetEntity = this.getNextNode();
		IncomingToken incomingTokenEvent = new IncomingToken(e.getTokenId(), e.getTime(),
								targetEntity, e.getStartTimestamp());
		targetEntity.dispatchEventOn(incomingTokenEvent);
		//l.addEvent(incomingTokenEvent);

		//LOG
		System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
		+ ": Scheduled INCOMING TOKEN event at time "
		+ incomingTokenEvent.getTime() + " "
		+ "for " + incomingTokenEvent.getTargetEntity().getName());


		//check for enqueued tokens waiting for a free resource
		if(!tokenQueue.isEmpty() && checkForAvailableResource() && !messageQueue.isEmpty()) {

			IncomingToken dequeuedToken = (IncomingToken)tokenQueue.pollFirst();
			//update the time of the dequeued token to now before processing it
			dequeuedToken.setTime(engine.getSimulationTime());
			processToken(dequeuedToken);
		}
		else {
			/*
			 * If the resource is also assigned to other tasks, the same check must
			 * be performed for all. The first token waiting in the queue of a task
			 * is processed.
			 * 
			 * For a ReceiveTask is also checked whether a message is available 
			 * */
			ArrayList<Task> tasks = r.getTasks();
			for(Task t : tasks) {
				if(t.hasPendingTokens()){
				/*if((!(t instanceof ReceiveTask)) && !t.tokenQueue.isEmpty()
						||
				(t instanceof ReceiveTask) && !((ReceiveTask)t).messageQueue.isEmpty() &&!t.tokenQueue.isEmpty() ){*/
					/*
					 * found a Task associated to r in which at least
					 * a token is still waiting in the token queue
					 */
					IncomingToken token = (IncomingToken)t.tokenQueue.pollFirst();
					//update the time of the dequeued token to now before processing it
					token.setTime(e.getTime());

					//LOG
					System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
						+ ": Resource " + r.getName() + " find pending Token " +  token.getTokenId()
						+ " still waiting in queue at " + t.getName());

					t.processToken(token);
				}
			}

		}

	}

	
	private void ProcessMessage(IncomingMessage message) {
		/*
		 * If the token queue is not empty, the message is consumed
		 * and the first token in the queue is processed.
		 * Otherwise the message is enqueued.
		 *
		 */
		messageQueue.add(message);
		if(!tokenQueue.isEmpty() && checkForAvailableResource()) {
			IncomingToken dequeuedToken = (IncomingToken)tokenQueue.pollFirst();
			//update the time of the dequeued token to now before processing it
			dequeuedToken.setTime(engine.getSimulationTime());
			this.processToken(dequeuedToken);	
		} else {
			System.out.println(this.engine.getSimulationTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + " Token queue is empty or no available resource found. The message is enqueued");
		}
	}

	@Override
	public boolean hasPendingTokens() {
		/* A pending token is a token waiting in the queue that becomes eligible for processing
		 * when the associated resource is available.
		 * In a Receive Task, the availability of a message must also be verified.
		 */
		return super.hasPendingTokens() && !isMessageQueueEmpty();
	}
	
	protected void log(String tokenId, double tokenLogicalTime, double serviceTime, String remoteEntity, String messagePayload) {

		LogData ld = new LogData(); 
		
		//token ID corresponds to the case ID
		ld.setCaseId(tokenId);  
		
		/*
		 * As the service is a double, its value is divided into seconds and nanoseconds
		 * to appropriately increase the (long) physical time value to be logged
		 */
		long seconds, serviceSeconds;
		long nanos;
		seconds = (long) tokenLogicalTime;
        nanos = (long) ((tokenLogicalTime - seconds) * 1_000_000_000);
        
        //The start time is the initial time + the current token logical time
        ld.setStartTimestamp(initialTime.plusSeconds(seconds).plusNanos(nanos).format(dateTimeFormat));
        
        //the completion time is obtained adding the service time
        serviceSeconds = (long) serviceTime;
        seconds +=  serviceSeconds;
        nanos += (long) ((serviceTime - serviceSeconds) * 1_000_000_000);
        ld.setCompleteTimestamp(initialTime.plusSeconds(seconds).plusNanos(nanos).format(dateTimeFormat));
        
        /*if more than one resource is required, the resource list is
         * logged as a string in which the various value are separated by
         * a ':' character
         */
        String res = "";
        String roles = "";
        if (resources.size()>0) {
        	res = resources.get(0).getName();
        	roles = resources.get(0).getRole();
        	if (resources.size()>1) {
        		for (int i = 1; i < resources.size(); i++) {
	        		res += ":" + resources.get(i).getName();
	        		roles += ":" + resources.get(i).getRole();
	        	}		
        	}
        }
        ld.setActivity(this.name);
        ld.setResources(res);
        ld.setRoles(roles);
        ld.setLocalEntity(this.getParticipant().getName());
        ld.setRemoteEntity(remoteEntity);
        ld.setCommType(CommunicationKind.receive);
        ld.setData(messagePayload);
		
        this.writeLog(ld);
	}

}
