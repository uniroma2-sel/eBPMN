package it.uniroma2.sel.ebpmn.exceptions;

public class BPMNException extends Exception{

	public BPMNException() {
		super();
	}

	public BPMNException(String message) {
		super(message);
	}

}
