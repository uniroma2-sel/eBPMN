package it.uniroma2.sel.ebpmn.exceptions;

public class EventInThePastException extends Exception{

	public EventInThePastException() {
		super();
	}

	public EventInThePastException(String message) {
		super(message);
	}


}
