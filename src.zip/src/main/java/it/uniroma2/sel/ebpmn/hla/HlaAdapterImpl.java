package it.uniroma2.sel.ebpmn.hla;
import hla.rti1516e.*;
import hla.rti1516e.encoding.EncoderFactory;
import hla.rti1516e.exceptions.*;
import hla.rti1516e.time.HLAfloat64TimeFactory;
import it.uniroma2.sel.ebpmn.events.IncomingMessage;
import it.uniroma2.sel.ebpmn.events.IncomingToken;

public class HlaAdapterImpl implements HlaAdapter {
    private final RTIambassador rti;
    private final EncoderFactory encoderFactory;
    private final FederateAmbassadorImpl ambassador;
    private final HLAfloat64TimeFactory timeFactory;
    private InteractionClassHandle incomingTokenHandle;
    private InteractionClassHandle incomingMessageHandle;
    private InteractionClassHandle joinNotificationClassHandle;

    public HlaAdapterImpl(RTIambassador rti, EncoderFactory encoderFactory, FederateAmbassadorImpl ambassador,
                          HLAfloat64TimeFactory timeFactory) {
        this.rti = rti;
        this.encoderFactory = encoderFactory;
        this.ambassador = ambassador;
        this.timeFactory = timeFactory;
    }

    @Override
    public InteractionClassHandle getIncomingMessageHandle() {
        return incomingMessageHandle;
    }

    @Override
    public InteractionClassHandle getIncomingTokenHandle() {
        return incomingTokenHandle;
    }

    @Override
    public InteractionClassHandle getJoinNotificationClassHandle() {
        return joinNotificationClassHandle;
    }

    @Override
    public void publishJoinNotificationInteraction(){
        //Non controller federates publish the Join Notification interaction to notify when they join the federation
        try {
            joinNotificationClassHandle = rti.getInteractionClassHandle("HLAinteractionRoot.FederationJoined");
            rti.publishInteractionClass(joinNotificationClassHandle);
        } catch (NameNotFound | FederateNotExecutionMember | NotConnected | RTIinternalError
                 | InteractionClassNotDefined
                 | SaveInProgress | RestoreInProgress e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void subscribeJoinNotificationInteraction() {
        //The controller subscribes the Join Notification interaction to be aware of new federates that join the federation
        try {
            joinNotificationClassHandle = rti.getInteractionClassHandle("HLAinteractionRoot.FederationJoined");
            rti.subscribeInteractionClass(joinNotificationClassHandle);
        } catch (NameNotFound | FederateNotExecutionMember | NotConnected | RTIinternalError
                | FederateServiceInvocationsAreBeingReportedViaMOM | InteractionClassNotDefined
                | SaveInProgress | RestoreInProgress e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void publishAndSubscribeEBPMNInteractions(){
        //Publish and subscribe the eBPMN-related interactions: IncomingToken, IncomingMessage
        try {
            incomingTokenHandle = rti.getInteractionClassHandle("HLAinteractionRoot.IncomingToken");
            rti.publishInteractionClass(incomingTokenHandle);
            rti.subscribeInteractionClass(incomingTokenHandle);
            incomingMessageHandle = rti.getInteractionClassHandle("HLAinteractionRoot.IncomingMessage");
            rti.publishInteractionClass(incomingMessageHandle);
            rti.subscribeInteractionClass(incomingMessageHandle);

        } catch (NameNotFound | FederateNotExecutionMember | NotConnected | RTIinternalError |
                 InteractionClassNotDefined | SaveInProgress | RestoreInProgress |
                 FederateServiceInvocationsAreBeingReportedViaMOM e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void sendJoinNotificationInteraction() {
        //Non controller federates send the Join Notification interaction to notify when they join the federation
        ParameterHandleValueMap parameters = null; //no parameters are needed
        try {
            parameters = rti.getParameterHandleValueMapFactory().create(0);
            rti.sendInteraction(joinNotificationClassHandle, parameters, null);
        } catch (FederateNotExecutionMember | NotConnected | InteractionClassNotPublished |
                 InteractionParameterNotDefined | InteractionClassNotDefined | SaveInProgress | RestoreInProgress |
                 RTIinternalError e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void sendIncomingToken(IncomingToken token)  {
        //To identify an entity n the distributed simulation the name is in the form <Participant name>:<flowNode name>
        String remoteEntityFullName = token.getTargetEntity().getParticipant().getName() + ":" + token.getTargetEntity().getName();

        try {
            ParameterHandleValueMap params = rti.getParameterHandleValueMapFactory().create(3);
            //InteractionClassHandle handle = interactions.getIncomingTokenHandle();

            params.put(rti.getParameterHandle(incomingTokenHandle, "tokenID"),
                    encoderFactory.createHLAunicodeString(token.getTokenId()).toByteArray());
            params.put(rti.getParameterHandle(incomingTokenHandle, "tokenTargetNode"),
                    encoderFactory.createHLAunicodeString(remoteEntityFullName).toByteArray());
            params.put(rti.getParameterHandle(incomingTokenHandle, "startTime"),
                    encoderFactory.createHLAfloat64BE(token.getStartTimestamp()).toByteArray());
            rti.sendInteraction(incomingTokenHandle, params, null);
        } catch (FederateNotExecutionMember | NotConnected | InteractionParameterNotDefined | RestoreInProgress |
                 InvalidInteractionClassHandle | InteractionClassNotDefined | InteractionClassNotPublished |
                 NameNotFound | SaveInProgress | RTIinternalError e) {
            throw new RuntimeException(e);}
    }

    @Override
    public void sendIncomingMessage(IncomingMessage message){
        //To identify an entity n the distributed simulation the name is in the form <Participant name>:<flowNode name>
        String sourceNodeFullName = message.getSourceEntity().getParticipant().getName() + ":" + message.getSourceEntity().getName();
        String targetNodeFullName = message.getTargetEntity().getParticipant().getName() + ":" + message.getTargetEntity().getName();

        try {
            ParameterHandleValueMap params;
            params = rti.getParameterHandleValueMapFactory().create(3);
            //InteractionClassHandle handle = interactions.getIncomingMessageHandle();
            params.put(rti.getParameterHandle(incomingMessageHandle, "messageSourceNode"),
                    encoderFactory.createHLAunicodeString(sourceNodeFullName).toByteArray());
            params.put(rti.getParameterHandle(incomingMessageHandle, "messageTargetNode"),
                    encoderFactory.createHLAunicodeString(targetNodeFullName).toByteArray());
            params.put(rti.getParameterHandle(incomingMessageHandle, "message"),
                    encoderFactory.createHLAunicodeString(message.getMessagePayload()).toByteArray());
            rti.sendInteraction(incomingMessageHandle, params, null);
        } catch (FederateNotExecutionMember | NotConnected | NameNotFound | InvalidInteractionClassHandle |
                 RTIinternalError | InteractionClassNotPublished | InteractionParameterNotDefined |
                 InteractionClassNotDefined | SaveInProgress | RestoreInProgress e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void requestTimeAdvance(double time) {
        try {
            rti.nextMessageRequest(timeFactory.makeTime(time));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void waitForTimeAdvanceGrant() throws InterruptedException {
        ambassador.setAdvancingState();
        //wait for the RTI to invoke the timeAdvanceGrant callback
        synchronized (ambassador) {
            while(ambassador.isAdvancing()){
                ambassador.wait();
            }
        }
    }
}