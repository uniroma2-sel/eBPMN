package it.uniroma2.sel.ebpmn.hla;

import hla.rti1516e.InteractionClassHandle;
import hla.rti1516e.ObjectClassHandle;
import it.uniroma2.sel.ebpmn.events.IncomingMessage;
import it.uniroma2.sel.ebpmn.events.IncomingToken;

public interface HlaAdapter {
    void publishJoinNotificationInteraction();
    void subscribeJoinNotificationInteraction();
    void sendJoinNotificationInteraction();
    void publishAndSubscribeEBPMNInteractions();
    void sendIncomingToken(IncomingToken token);
    void sendIncomingMessage(IncomingMessage message);
    void requestTimeAdvance(double time);
    void waitForTimeAdvanceGrant() throws InterruptedException;
    InteractionClassHandle getIncomingMessageHandle();
    InteractionClassHandle getIncomingTokenHandle();
    InteractionClassHandle getJoinNotificationClassHandle();
}