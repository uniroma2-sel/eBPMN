package it.uniroma2.sel.ebpmn.events;

import it.uniroma2.sel.ebpmn.bpmn.FlowNode;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;

public class IncomingToken extends Token {

	public IncomingToken(String id, double time, FlowNode entity) {
		super(id, time, entity);
	}
	public IncomingToken(String id, double time, FlowNode entity, double startTime) {
		super(id, time, entity, startTime);
	}

	@Override
	public void processOn(FlowNode node) throws UnexpectedEvent {
		node.handleEvent(this);  // double dispatch
	}
}
