package it.uniroma2.sel.ebpmn;



import it.uniroma2.sel.ebpmn.bpmn.Node;
import it.uniroma2.sel.ebpmn.bpmn.Participant;
import it.uniroma2.sel.ebpmn.engine.ExecutionEngine;
import it.uniroma2.sel.ebpmn.events.Event;
import it.uniroma2.sel.ebpmn.events.IncomingMessage;
import it.uniroma2.sel.ebpmn.events.IncomingToken;


/*
* A RemoteNode is a proxy that handles events (incoming tokens and incoming messages)
* dispatched to remote BPMN entities whose implementation is provided by a different Federate
* The incoming (local) events are mapped to interactions routed (via the RTI to the intended recipient).
* Such interactions will be finally used by receiving Federates to create local events accordingly.
*
* */
public class RemoteNode implements Node {
    protected String name;		//name of the bpmn flow node
    protected Participant p;		//participant that contains the bpmn flow node

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Participant getParticipant() {
        return getParticipant();
    }

    @Override
    public void dispatchEventOn(Event e) {
        if (e instanceof IncomingMessage m) {
            ExecutionEngine.getInstance().getAdapter().sendIncomingMessage((IncomingMessage) m);
        } else if (e instanceof IncomingToken t) {
            ExecutionEngine.getInstance().getAdapter().sendIncomingToken((IncomingToken) e);
        } else {
            throw new UnsupportedOperationException(
                    "RemoteNode does not support an event of type: " + e.getClass().getSimpleName()
            );
        }
    }
}
