package it.uniroma2.sel.ebpmn.exceptions;

public class UnexpectedEvent extends Exception{

	public UnexpectedEvent() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UnexpectedEvent(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
