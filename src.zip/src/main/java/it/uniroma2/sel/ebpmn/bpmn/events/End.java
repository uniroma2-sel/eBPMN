package it.uniroma2.sel.ebpmn.bpmn.events;

import it.uniroma2.sel.ebpmn.bpmn.FlowNode;
import it.uniroma2.sel.ebpmn.bpmn.Participant;
import it.uniroma2.sel.ebpmn.engine.ExecutionEngine;
import it.uniroma2.sel.ebpmn.events.*;
import it.uniroma2.sel.ebpmn.exceptions.BPMNException;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;

public class End extends FlowNode{

	private int processedToken;
	private double avgServiceTime;

	public End(String name, Participant p) {
		super(name, p);
		processedToken = 0;
		avgServiceTime=0;
	}



	public int getProcessedToken() {
		return processedToken;
	}


	public double getAvgServiceTime() {
		return avgServiceTime;
	}


	@Override
	public void addOutGoingEdge(FlowNode n) throws BPMNException{
		throw new BPMNException(this.name + " cannot have an outogoing edge");

	}

	@Override
	public FlowNode getNextNode() throws BPMNException{
		throw new BPMNException("Unable to find an activity node after " + this.name);
	}

	@Override
	public void handleEvent(IncomingToken incomingToken) throws UnexpectedEvent {
		//compute of the mean service time
		double serviceTime = incomingToken.getTime()-incomingToken.getStartTimestamp();
		avgServiceTime = ((avgServiceTime*processedToken)+serviceTime)/(processedToken+1);
		processedToken++;

		//LOG
		System.out.println(incomingToken.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
				+ ": Token " + incomingToken.getTokenId() + " execution completed in " + serviceTime);
	}

	/*
	@Override
	public void handleEvent(Event e) throws UnexpectedEvent {

		//compute of the mean service time
		double serviceTime = e.getTime()-e.getStartTimestamp();
		avgServiceTime = ((avgServiceTime*processedToken)+serviceTime)/(processedToken+1);
		processedToken++;

		//LOG
		if(e instanceof IncomingToken)
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() 
					+ ": Token "
		+ ((IncomingToken)e).getTokenId() + " execution completed in " + serviceTime);

		else
			throw new UnexpectedEvent("Node " + this.getName() +
					"has received an unexpected " + e.getClass().getName() + " event type");
		engine.getEventsList().removeEvent(e);


	}*/

}
