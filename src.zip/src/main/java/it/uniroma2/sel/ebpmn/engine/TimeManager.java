package it.uniroma2.sel.ebpmn.engine;

public interface TimeManager {
    double advanceTo(double newTime);
    double getCurrentTime();

}


