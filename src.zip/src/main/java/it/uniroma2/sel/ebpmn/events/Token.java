package it.uniroma2.sel.ebpmn.events;

import it.uniroma2.sel.ebpmn.bpmn.FlowNode;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;
import it.uniroma2.sel.ebpmn.resources.Resource;

public abstract class Token extends Event{
	private String tokenId;
	private Resource resource;  //potential resource responsible for the actual
								//execution of the activity

	public Token(String id, double time, FlowNode entity) {
		super(time, entity);
		tokenId=id;

	}

	public Token(String id, double time, FlowNode entity, double startTime) {
		super(time, entity, startTime);
		tokenId=id;
	}

	public void setTokenId(String id) {
		this.tokenId=id;
	}

	public String getTokenId() {
		return this.tokenId;
	}

	public void setResource(Resource r) {
		this.resource = r;
	}

	public Resource getResource() {
		return this.resource;
	}
}
