package it.uniroma2.sel.ebpmn.bpmn.tasks;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.TreeSet;

import it.uniroma2.sel.ebpmn.bpmn.FlowNode;
import it.uniroma2.sel.ebpmn.bpmn.Participant;
import it.uniroma2.sel.ebpmn.events.*;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;
import it.uniroma2.sel.ebpmn.logger.CommunicationKind;
import it.uniroma2.sel.ebpmn.logger.LogData;
import it.uniroma2.sel.ebpmn.resources.Resource;
import it.uniroma2.sel.ebpmn.generators.RandomVariableGenerator;

public class Task extends FlowNode{
	/*
	 * A random variable generator is used to generate the service time
	 * according to a given probability distribution
	 */
	protected RandomVariableGenerator generator;
	protected ArrayList<Resource> resources;
	protected int lastResourceIndex; //last used resource to implement a round robin policy
	protected EventsList l;
	protected LocalDateTime initialTime;
	protected DateTimeFormatter dateTimeFormat;
	protected double serviceTime; 
	protected TreeSet<Event> tokenQueue; //queue of incoming token

	public Task(String name, Participant p, RandomVariableGenerator gen) {
		super(name, p);
		this.generator = gen;
		resources = new ArrayList<>();
		lastResourceIndex=-1;
		tokenQueue = new TreeSet<>();
	}

	@Override
	public void handleEvent(IncomingToken incomingToken) throws UnexpectedEvent{
		//LOG
		System.out.println(incomingToken.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
				+ ": Received INCOMING TOKEN, Token ID " + incomingToken.getTokenId());
		processToken(incomingToken);
	}

	@Override
	public void handleEvent(TokenServiceCompleted servedToken) throws UnexpectedEvent {
		System.out.println(servedToken.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
				+ ": Received SERVICE COMPLETE, Token ID " + servedToken.getTokenId());
		completeTokenService(servedToken);
	}

	//@Override
	/*
	public void handleEvent(Event e) {

		if(e instanceof IncomingToken) {

			processToken((IncomingToken)e);
		}

		else if(e instanceof TokenServiceCompleted) {

		}

		else
	}*/

	public void addResource(Resource r) {
		this.resources.add(r);
		r.addTask(this);
	}

	public ArrayList<Resource> getResources() {
		return this.resources;
	}

	@Override
	public void addOutGoingEdge(FlowNode n) {
		this.nodes.add(n);
	}

	@Override
	//A Task node has exactly 1 outgoing edge
	public FlowNode getNextNode() {
		return this.nodes.get(0);
	}

	/*
	 * A task is associated to a pool of resources which are in charge of
	 * executing or overseeing the relevant activity. Resources might be responsible
	 * of more than one task.
	 *
	 * */
	protected void processToken(IncomingToken t) {
		initialTime = engine.getInitialTime();
		dateTimeFormat = engine.getDateTimeFormat(); 
		
		if (checkForAvailableResource()) {
			/* if at least on resource is available and the token queue is
			 * empty, the token is processed otherwise it is enqueued.
			 *
			 */
			//find the next to be used according to a round robin policy
			Resource r = this.getAvailableResource();

			//DEBUG
			System.out.println(t.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": Found available resource " + r.getName() );
			System.out.println(t.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": Starting processing of Token ID " + t.getTokenId());
			

			//mark the resource as busy
			r.setBusy();

			//a SERVICE_COMPLETE event is scheduled on this entity
			serviceTime = generator.get();
			TokenServiceCompleted serviceCompleteEvent = new TokenServiceCompleted(t.getTokenId(),
					t.getTime()+serviceTime, this, t.getStartTimestamp());
			serviceCompleteEvent.setResource(r);
			this.dispatchEventOn(serviceCompleteEvent);
			//ERA l.addEvent(serviceCompleteEvent);

			//Writing the log entry
			log(t.getTokenId(), t.getTime(), serviceTime);
	        
			//LOG
			System.out.println(t.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": Scheduled SERVICE COMPLETE event for Token ID " + serviceCompleteEvent.getTokenId() + " at time "
				+ serviceCompleteEvent.getTime()
				+ " for " + serviceCompleteEvent.getTargetEntity().getName());
		} else {
			//the token is enqueued
			this.tokenQueue.add(t);
			System.out.println(t.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": Token ID " + t.getTokenId() + " enqueued");
		}
	}
	
	protected void completeTokenService(TokenServiceCompleted token) {
		//LOG
		System.out.println(token.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": Token ID " + token.getTokenId() + " Service completed");
		System.out.println(token.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": Resource " + token.getResource().getName() + " is now free");
		//the involved resource is marked as available
		Resource r = token.getResource();
		r.free();

		/*
		 * To route the token towards the next node, a new INCOMING_TOKEN event is created and dispatched to the target entity
		 * */
		FlowNode targetEntity = this.getNextNode();
		IncomingToken incomingTokenEvent = new IncomingToken(token.getTokenId(), token.getTime(),
				targetEntity, token.getStartTimestamp());
		targetEntity.dispatchEventOn(incomingTokenEvent);
		//l.addEvent(incomingTokenEvent);


		//LOG
		System.out.println(token.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
			+ ": Scheduled INCOMING TOKEN event at time "
			+ incomingTokenEvent.getTime() + " "
			+ "for " + incomingTokenEvent.getTargetEntity().getName());


		//check for enqueued tokens waiting for a free resource
		if(!tokenQueue.isEmpty() && checkForAvailableResource()) {
			IncomingToken dequeuedToken = (IncomingToken)tokenQueue.pollFirst();
			//update the time of the dequeued token to now before processing it
			
			System.out.println(token.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": Found Token ID " + dequeuedToken.getTokenId() + " in queue with availabe resources" );
			
			dequeuedToken.setTime(engine.getSimulationTime());
			processToken(dequeuedToken);
		}
		else {
			/*
			 * If the resource is also assigned to other tasks, the same check must
			 * be performed for all. The first token waiting in the queue of a task
			 * is processed.
			 * */
			
			System.out.println(token.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": No token in queue or available resources found. Inspecting other nodes served by resource " + r.getName() );
			
			ArrayList<Task> tasks = r.getTasks();
			//tasks.remove(this);
			for(Task t : tasks) {

				if(t.hasPendingTokens()){
				/*
				if((!(t instanceof ReceiveTask)) && !t.tokenQueue.isEmpty()
						||
				(t instanceof ReceiveTask) && !((ReceiveTask)t).isMessageQueueEmpty() && !t.tokenQueue.isEmpty()) {
				*/

					/*
					 * found a Task associated to r in which at least
					 * a token is still waiting in the token queue
					 */
					IncomingToken iToken = (IncomingToken)t.tokenQueue.pollFirst();
					//update the time of the dequeued token to now before processing it
					iToken.setTime(token.getTime());

					//LOG
					System.out.println(token.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName() + ": Resource " + r.getName() + " find pending Token " +  token.getTokenId()
						+ " still waiting in queue at " + t.getName());

					t.processToken(iToken);
					break; //if a task is discovered the resource became busy
				}
			}

		}

	}
	
	protected void log(String tokenId, double tokenLogicalTime, double serviceTime) {
		LogData ld = new LogData(); 
		
		//token ID corresponds to the case ID
		ld.setCaseId(tokenId);  
		
		/*
		 * As the service is a double, its value is divided into seconds and nanoseconds
		 * to appropriately increase the (long) physical time value to be logged
		 */
		long seconds, serviceSeconds;
		long nanos;
		seconds = (long) tokenLogicalTime;
        nanos = (long) ((tokenLogicalTime - seconds) * 1_000_000_000);
        
        //The start time is the initial time + the current token logical time
        ld.setStartTimestamp(initialTime.plusSeconds(seconds).plusNanos(nanos).format(dateTimeFormat));
        
        //the completion time is obtained adding the service time
        serviceSeconds = (long) serviceTime;
        seconds +=  serviceSeconds;
        nanos += (long) ((serviceTime - serviceSeconds) * 1_000_000_000);
        ld.setCompleteTimestamp(initialTime.plusSeconds(seconds).plusNanos(nanos).format(dateTimeFormat));
        
        /*if more than one resource is required, the resource list is
         * logged as a string in which the various value are separated by
         * a ':' character
         */
        String res = "";
        String roles = "";
        if (resources.size()>0) {
        	res = resources.get(0).getName();
        	roles = resources.get(0).getRole();
        	if (resources.size()>1) {
        		for (int i = 1; i < resources.size(); i++) {
	        		res += ":" + resources.get(i).getName();
	        		roles += ":" + resources.get(i).getRole();
	        	}		
        	}
        }
        ld.setActivity(this.name);
        ld.setResources(res);
        ld.setRoles(roles);
        ld.setLocalEntity(this.getParticipant().getName());
        ld.setRemoteEntity("");
        ld.setCommType(CommunicationKind.ND);
        ld.setData("");
	
        this.writeLog(ld);
	}

	protected boolean checkForAvailableResource() {
		boolean available=false;
		for(Resource r : this.resources) {
			available = available || r.isAvailabe();
			if (available)
				break;

		}
		return available;
	}

	protected Resource getAvailableResource() {
		//an available resource is identified according to a round robin discipline
		do
			lastResourceIndex = (lastResourceIndex + 1)%this.resources.size();
		while(!resources.get(lastResourceIndex).isAvailabe());
		return resources.get(lastResourceIndex);
	}

	/* A pending token is a token waiting in the queue that becomes eligible for processing
	 * when the associated resource is available.*/
	protected boolean hasPendingTokens() {
		return !tokenQueue.isEmpty();
	}

}
