package it.uniroma2.sel.ebpmn.events;

import it.uniroma2.sel.ebpmn.bpmn.FlowNode;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;

public class StartProcess extends Event{
	public StartProcess(double time, FlowNode entity) {
		super(time, entity);
	}

	@Override
	public void processOn(FlowNode node) throws UnexpectedEvent{
		node.handleEvent(this);  // double dispatch
	}

}
