package it.uniroma2.sel.ebpmn.logger;

//import java.time.LocalDateTime;

public class LogData {
	private String caseId;
	private String startTimestamp;
	private String completeTimestamp;
	private String activity;
	private String resources; // colon separated resource list  
	private String roles;	  // colon separated role list
	private String localEntity;
	private String remoteEntity;
	private CommunicationKind commType;
	private String data;
	
	public LogData() {};
	
	public LogData(String caseId, String startTimestamp, String completeTimestamp, String activity,
			String resources, String roles, String localEntity, String remoteEntity, CommunicationKind commType,
			String iP, String data) {
		this.caseId = caseId;
		this.startTimestamp = startTimestamp;
		this.completeTimestamp = completeTimestamp;
		this.activity = activity;
		this.resources = resources;
		this.roles = roles;
		this.localEntity = localEntity;
		this.remoteEntity = remoteEntity;
		this.commType = commType;
		this.data = data;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getStartTimestamp() {
		return startTimestamp;
	}

	public void setStartTimestamp(String string) {
		this.startTimestamp = string;
	}

	public String getCompleteTimestamp() {
		return completeTimestamp;
	}

	public void setCompleteTimestamp(String string) {
		this.completeTimestamp = string;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getResources() {
		return resources;
	}

	public void setResources(String resources) {
		this.resources = resources;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public String getLocalEntity() {
		return localEntity;
	}

	public void setLocalEntity(String localEntity) {
		this.localEntity = localEntity;
	}

	public String getRemoteEntity() {
		return remoteEntity;
	}

	public void setRemoteEntity(String remoteEntity) {
		this.remoteEntity = remoteEntity;
	}

	public CommunicationKind getCommType() {
		return commType;
	}

	public void setCommType(CommunicationKind commType) {
		this.commType = commType;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
	
	
	
	
}
