package it.uniroma2.sel.ebpmn.generators;

import java.util.Random;

public class ExponentialGenerator implements RandomVariableGenerator {
	private final Random random = new Random();
    private final double lambda; // 1/mean value

    public ExponentialGenerator(double lambda) {
        this.lambda = lambda;
    }

    @Override
    public double get() {
    	/*
    	 * Generation of a random number according to an Exponential (lambda)
    	 * probability distribution
    	 */
        return -Math.log(1 - random.nextDouble()) / lambda;
    }
}
