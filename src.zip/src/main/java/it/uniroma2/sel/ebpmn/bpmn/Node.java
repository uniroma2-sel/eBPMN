package it.uniroma2.sel.ebpmn.bpmn;

import it.uniroma2.sel.ebpmn.events.Event;
import it.uniroma2.sel.ebpmn.exceptions.BPMNException;

/*The node interface provides the behavior or local and remote BPMN simulation entities*/
public interface Node {
    public String getName();
    public Participant getParticipant();
    public void dispatchEventOn(Event e);

}


