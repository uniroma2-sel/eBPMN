package it.uniroma2.sel.ebpmn.bpmn.tasks;

import it.uniroma2.sel.ebpmn.bpmn.FlowNode;
import it.uniroma2.sel.ebpmn.bpmn.Participant;
import it.uniroma2.sel.ebpmn.events.IncomingMessage;
import it.uniroma2.sel.ebpmn.events.TokenServiceCompleted;
import it.uniroma2.sel.ebpmn.logger.CommunicationKind;
import it.uniroma2.sel.ebpmn.logger.LogData;
import it.uniroma2.sel.ebpmn.generators.RandomVariableGenerator;

public class SendTask extends Task{

	private FlowNode nextEntity; //next node connected an outgoing edge
	private FlowNode targetNode; //node connected with a message flow
    private String messageData;

	public SendTask(String name, Participant p, RandomVariableGenerator gen) {
		super(name, p, gen);
	}
	
	public void addMessageFlow(FlowNode targetNode, String data) {
		this.targetNode = targetNode;
		this.messageData = data;
	}
	
	@Override
	protected void completeTokenService(TokenServiceCompleted e) {
		// call the superclass method
		super.completeTokenService(e);
		
		/* The required message is sent after completing the process of an incoming token event.
		 * To send a message to the target node a corresponding INCOMING MESSAGE EVENT
		 * is scheduled.
		 */
		IncomingMessage message = new IncomingMessage(e.getTime(),this, targetNode, messageData);
		//engine.getEventsList().addEvent(message);
		targetNode.dispatchEventOn(message);

		//LOG
		System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
		+ ": Scheduled INCOMING MESSAGE event at time "
		+ message.getTime() + " for " + message.getTargetEntity().getName());
	}

	@Override
	protected void log(String tokenId, double tokenLogicalTime, double serviceTime) {
		LogData ld = new LogData(); 
		
		//token ID corresponds to the case ID
		ld.setCaseId(tokenId);  
		
		/*
		 * As the service is a double, its value is divided into seconds and nanoseconds
		 * to appropriately increase the (long) physical time value to be logged
		 */
		long seconds, serviceSeconds;
		long nanos;
		seconds = (long) tokenLogicalTime;
        nanos = (long) ((tokenLogicalTime - seconds) * 1_000_000_000);
        
        //The start time is the initial time + the current token logical time
        ld.setStartTimestamp(initialTime.plusSeconds(seconds).plusNanos(nanos).format(dateTimeFormat));
        
        //the completion time is obtained adding the service time
        serviceSeconds = (long) serviceTime;
        seconds +=  serviceSeconds;
        nanos += (long) ((serviceTime - serviceSeconds) * 1_000_000_000);
        ld.setCompleteTimestamp(initialTime.plusSeconds(seconds).plusNanos(nanos).format(dateTimeFormat));
        
        /*if more than one resource is required, the resource list is
         * logged as a string in which the various value are separated by
         * a ':' character
         */
        String res = "";
        String roles = "";
        if (resources.size()>0) {
        	res = resources.get(0).getName();
        	roles = resources.get(0).getRole();
        	if (resources.size()>1) {
        		for (int i = 1; i < resources.size(); i++) {
	        		res += ":" + resources.get(i).getName();
	        		roles += ":" + resources.get(i).getRole();
	        	}		
        	}
        }
        ld.setActivity(this.name);
        ld.setResources(res);
        ld.setRoles(roles);
        ld.setLocalEntity(this.getParticipant().getName());
        ld.setRemoteEntity(this.targetNode.getParticipant().getName());
        ld.setCommType(CommunicationKind.send);
        ld.setData(this.messageData);
		
        this.writeLog(ld);
	}
}
