package it.uniroma2.sel.ebpmn.logger;

public enum CommunicationKind {
	send,
	receive,
	send_receive,
	ND;
	
	@Override
    public String toString() {
        return this == ND ? "" : this.name();
    }
}
