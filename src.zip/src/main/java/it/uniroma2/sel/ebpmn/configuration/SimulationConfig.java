package it.uniroma2.sel.ebpmn.configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;

public class SimulationConfig {
    public enum SimulationType {LOCAL, DISTRIBUTED}

    private SimulationType simulationType;
    private String federationName;
    private String federateName;
    private boolean controller;
    private int numbersOfFederates;
    private String rtiHostName;
    private int rtiPortNumber;
    private double simulationLength;
    private int numberOfTokens;
    private double advancingStep;
    private double lookahead;
    private double startTime;

    public SimulationConfig() {
    }

    public static SimulationConfig load(String path) throws IOException {
        return new ObjectMapper().readValue(new File(path), SimulationConfig.class);
    }

    public SimulationType getSimulationType() {
        return simulationType;
    }

    public String getRtiHostName() {
        return rtiHostName;
    }

    public int getRtiPortNumber() {
        return rtiPortNumber;
    }

    public String getFederationName() {
        return federationName;
    }

    public String getFederateName() {
        return federateName;
    }

    public int getNumbersOfFederates() {
        return numbersOfFederates;
    }

    public double getSimulationLength() {
        return simulationLength;
    }

    public int getNumberOfTokens() { return numberOfTokens;}

    public double getAdvancingStep() {
        return advancingStep;
    }

    public double getLookahead() {
        return lookahead;
    }

    public double getStartTime() {return startTime;}

    public boolean isController() {
        return controller;
    }

    @Override
    public String toString() {
        return String.format("SimulationConfig Type=%s, RTI=%s:%d, federationName=%s, federateName=%s, iscontroller=%b" +
                        "numbersOfFederate=%d, simulationLength=%.1f, advancingStep=%.2f, lookahead=%f, startTime=%f",
                simulationType, rtiHostName, rtiPortNumber, federationName, federateName, controller,
                numbersOfFederates, simulationLength, advancingStep, lookahead, startTime);
    }
}
