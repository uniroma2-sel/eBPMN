package it.uniroma2.sel.ebpmn.bpmn.gateways;

import java.util.ArrayList;

import it.uniroma2.sel.ebpmn.bpmn.FlowNode;
import it.uniroma2.sel.ebpmn.bpmn.Participant;
import it.uniroma2.sel.ebpmn.events.Event;
import it.uniroma2.sel.ebpmn.events.IncomingToken;
import it.uniroma2.sel.ebpmn.exceptions.BPMNException;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;

public class ExclusiveDivergingGateway extends FlowNode{

	/*
	 * In the current implementation it is assumed that the sum of the
	 * probabilities specified by the routingProb[] array is exactly 1.
	 * No checks are performed, and no exceptions are thrown.
	 */
	private ArrayList<Double> routingProb;	//routing probabilities

	public ExclusiveDivergingGateway(String name, Participant p) {
		super(name,p);
		routingProb = new ArrayList<>();
	}

	/*
	 * Creates an outgoing edge to the FlowNode n
	 * with a routing probability equal to p
	 */
	public  void addOutGoingEdge(FlowNode n, double p) throws BPMNException{
		this.nodes.add(n);			//adding edge
		this.routingProb.add(Double.valueOf(p));	//adding routing probability

		//check routing probability consistency
		double sum = 0;
		for(int i=0; i<=this.routingProb.size()-1; i++)
			sum+=routingProb.get(i);

		if(sum>1) throw new BPMNException("The sum of routing probability for the " + name + " gateway is greater that 1.0");
	}

	@Override
	public void handleEvent(IncomingToken incomingToken) throws UnexpectedEvent {
		//LOG
		System.out.println(incomingToken.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
				+ ": Received INCOMING TOKEN, Token ID " + incomingToken.getTokenId());

		Event t = new IncomingToken(incomingToken.getTokenId(), incomingToken.getTime(),
				this.nodes.get(this.getRoute()), incomingToken.getStartTimestamp());
		this.getNextNode().dispatchEventOn(t);
		//engine.getEventsList().addEvent(t);

		//LOG
		System.out.println(incomingToken.getTime() + ") " + this.getParticipant().getName() + " - "  + this.getName()
				+ ": Scheduled INCOMING TOKEN event at time "
				+ t.getTime() + " "
				+ "for " + t.getTargetEntity().getName());
	}

	/*
	@Override
	public void handleEvent(Event e) throws UnexpectedEvent {
		
		if(e instanceof IncomingToken) {
			
			//LOG
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
					+ ": Received INCOMING TOKEN, Token ID " + ((IncomingToken)e).getTokenId());
			
			Event t = new IncomingToken(((IncomingToken)e).getTokenId(), e.getTime(),
					this.nodes.get(this.getRoute()), e.getStartTimestamp());
			engine.getEventsList().addEvent(t);

			//LOG
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - "  + this.getName()
				+ ": Scheduled INCOMING TOKEN event at time "
				+ t.getTime() + " "
				+ "for " + t.getTargetEntity().getName());
		}
		else throw new UnexpectedEvent("Node " + this.getName() +
				"has received an unexpected " + e.getClass().getSimpleName().toUpperCase() + " event type");

	}

	*/

	@Override
	/*
	 * If no routing probability is specified, it is assumed that
	 * there is only one outgoing edge
	 */
	public void addOutGoingEdge(FlowNode n) {
		this.nodes.add(n);//adding edge
		this.routingProb.add(1.0);	//adding routing probability
	}

	/*
	 * According to the routing probabilities, the method identifies
	 * the index of an outgoing edge (which is then used to forward
	 * the token to the appropriate FlowNode element)
	 *
	 */
	private int getRoute() {
		int i=0;
		Double prob = this.routingProb.get(i);
		while(prob<=Math.random()) {
			i++;
			prob += this.routingProb.get(i);
		}
		return i;
	}

	//Gets the next node according to the routing probabilities
	@Override
	public FlowNode getNextNode() {
		return this.nodes.get(getRoute());
	}


}
