package it.uniroma2.sel.ebpmn.generators;

import java.util.Random;

public class NormalGenerator implements RandomVariableGenerator{
	private final Random random = new Random();
    private double mu;    // mean value
    private double sigma; // standard deviation

    public NormalGenerator(double mu, double sigma) {
        this.mu = mu;
        this.sigma = sigma;
    }

    @Override
    public double get() {
    	/*
    	 * Generation of a random number according to an Normal (mu, sigma) probability
    	 * distribution
    	*/
    	double d = random.nextGaussian();
    	return mu + sigma * d;
    }
}
