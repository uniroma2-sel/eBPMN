package it.uniroma2.sel.ebpmn.bpmn.gateways;

import it.uniroma2.sel.ebpmn.bpmn.FlowNode;
import it.uniroma2.sel.ebpmn.bpmn.Participant;
import it.uniroma2.sel.ebpmn.events.Event;
import it.uniroma2.sel.ebpmn.events.IncomingToken;
import it.uniroma2.sel.ebpmn.exceptions.UnexpectedEvent;

public class ExclusiveConvergingGateway extends FlowNode{

	public ExclusiveConvergingGateway(String name, Participant p) {
		super(name, p);
	}

	@Override
	public void addOutGoingEdge(FlowNode n) {
		this.nodes.add(n);

	}

	@Override
	public FlowNode getNextNode() {
		return this.nodes.get(0);
	}

	@Override
	public void handleEvent(IncomingToken incomingToken) throws UnexpectedEvent {
		//LOG
		System.out.println(incomingToken.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
				+ ": Received INCOMING TOKEN, Token ID " + incomingToken.getTokenId());
		String id = incomingToken.getTokenId();
		Event t = new IncomingToken(id, incomingToken.getTime(),
				this.getNextNode(), incomingToken.getStartTimestamp());
		this.getNextNode().dispatchEventOn(t);
		//engine.getEventsList().addEvent(t);

		//LOG
		System.out.println(incomingToken.getTime() + ") " + this.getParticipant().getName() + " - "  + this.getName()
				+ ": Scheduled INCOMING TOKEN event at time "
				+ t.getTime() + " "
				+ "for " + t.getTargetEntity().getName());
	}

	/*
	@Override
	public void handleEvent(Event e) throws UnexpectedEvent {
		//LOG
		System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - " + this.getName()
				+ ": Received INCOMING TOKEN, Token ID " + ((IncomingToken)e).getTokenId());
		
		if(e instanceof IncomingToken) {
			String id = ((IncomingToken)e).getTokenId();
			Event t = new IncomingToken(id, e.getTime(),
					this.getNextNode(), e.getStartTimestamp());
			engine.getEventsList().addEvent(t);

			//LOG
			System.out.println(e.getTime() + ") " + this.getParticipant().getName() + " - "  + this.getName()
				+ ": Scheduled INCOMING TOKEN event at time "
				+ t.getTime() + " "
				+ "for " + t.getTargetEntity().getName());
		}
		else throw new UnexpectedEvent("Node " + this.getName() +
				"has received an unexpected " + e.getClass().getSimpleName().toUpperCase() + " event type");


	}*/



}
