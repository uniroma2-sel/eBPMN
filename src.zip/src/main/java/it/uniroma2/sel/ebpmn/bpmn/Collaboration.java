package it.uniroma2.sel.ebpmn.bpmn;

import java.util.ArrayList;

public class Collaboration {

	String name;
	ArrayList<Participant> participants;


	public Collaboration(String name) {
		this.name = name;
		participants = new ArrayList<>();
	}

	public void addParticipant(Participant p) {
		participants.add(p);
	}

	public ArrayList<Participant> getParticipants(){
		return participants;
	}
}
